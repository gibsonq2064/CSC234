#include <iostream>

using namespace std;


//CSC 134
//M2Lab2
//Quentin Gibson


// Function prototypes
// list each room function here
void garden();
void gazebo();
void well();
void outsideShack();
void insideShack();
void Secrettunnel();
void trapdoor();
void exit();

// list global variables here
// (we would rather not use globals
// but they'll work for now)
bool firstPlay = true; // is this first playthrough
bool hasKey = false;   // do they have the key?
bool button = false;

int main()
{
    // this is probably more complex than needed

    char again;
    cout << "Welcome, traveler!" << endl;
    if (firstPlay) {
        cout << "Are you ready to begin your quest(y/n)? ";
    }
    else {
        cout << "Would you like to play again(y/n)? ";
    }
    cin >> again;
    if (again == 'y' || again == 'Y') {
        // start in garden
        garden();
        firstPlay = false;
        // loop back around to play again
        main();
    }
    else {
        cout << "Goodbye!" << endl;
    }

    return 0;
}


/*
Garden - leads to gazebo, shack, and well.
*/
void garden() {
    cout << "You are in the garden." << endl;
    cout << "A shack is to the EAST." << endl;
    cout << "there is a KEY here on the ground." << endl;
    cout << "a well is to the WEST" << endl;
    cout << "there is a gazebo to the NORTH" << endl;
    string command;
    cin >> command;
    if (command == "east") {
        outsideShack();
    }
    else if (command == "west"){
        well();
      
    }
    else if (command == "key") {
        hasKey = true;
        garden();
    }
    else if (command == "north"){
        gazebo();
      
    }
}


/*
Gazebo - leads back to garden also leads to secret ending
*/
void gazebo() {
  string command;
  cout << "You approach a gazebo" << endl;
  cout << "you can return SOUTH to the garden" << endl;
  cout << "The gazebo has a trap DOOR " << endl;
  cin >> command;
       if (command == "door") {
            Secrettunnel();
         }
        else if (command == "south"){
            garden();
        }


}

/*
Well - leads back to garden, or down to your doom.
*/
void well() {
  string command;
  cout << "You are at a well " << endl;
  cout << "You can return EAST to the garden" << endl;
  cout << "there is something shiny in the WELL" << endl;
  cin >> command;
      if (command == "east") {
            garden();
        }
        else if (command == "well") {
            button = true;
          cout << "you hear a weird click " << endl;
              well();
        }

}
  
/*
Outside Shack - leads back to garden or inside shack to victory
*/
void outsideShack() {
    string command;
    cout << "You are outside of a shack." << endl;
    cout << "You can return WEST to the garden." << endl;
    cout << "The DOOR is locked firmly." << endl;
    cin >> command;
    if (command == "door") {
        if (hasKey) {
            insideShack();
        }
        else {
            cout << "The door is locked." << endl;
        }
    }
}

void Secrettunnel(){
  string command;
  cout << "You have entered a dark tunnel" << endl;
  cout << "you can return UP to gazebo" << endl;
  cout << "There is a dim light FORWARD" << endl;
    cin >> command;
       if (command == "up") {
            gazebo();
        }
        else if (command == "forward"){
                trapdoor();
        }
  
}

void trapdoor(){
  string command;
  cout << "You reach a room with a trapdoor" << endl;
  cout << "There is a lever to your LEFT" << endl;
  cout << "There is another lever to your RIGHT" << endl;
  cout << "you can go BACK to return to tunnel" << endl;
  cin >> command;
  //Secondary win/lose condition 
  if (command == "left") {
        insideShack();
      
    }

  else if (command == "right"){
    if (button) {
      exit();
      
      
    }

    
  }

    
  else {
      cout << "the floor opens beneath you and you fall to your doom" << endl;
    cout << "GAME OVER!" << endl;
      
    }
}
void exit(){
  cout << "A hatch opens" << endl;
  cout << "you gain your freedom but lose the treasure" << endl;
  
}
/*
Inside Shack - win condition
*/
void insideShack() {
    cout << "The treasure is here -- you win!" << endl;
}
