#include <iostream>

int main() {
  std::cout << "Hello my name is Quentin Gibson\n" << std::endl;
  std::cout << "I took a C+ course last spring semester and this semester I am also      taking C++ and Python programming.\n" << std::endl;
  std::cout << " My hobbies include: playing video games, skateboarding, and tinkering    with electronics." << std::endl;
}